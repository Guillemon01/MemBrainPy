"""
Punto de entrada principal para usar MemBrainPy de forma cómoda.
Expone las clases y funciones más relevantes para importar directamente.
"""

# Importar la definición del modelo principal
from .SistemaP import SistemaP, Membrana, Regla

# Importar funciones de simulación y visualización
from .visualizadorAvanzado import simular_y_visualizar

# Importar sistemas de test predefinidos
from .tests_sistemas import (
    sistema_basico,
    sistema_con_conflictos,
    Sistema_complejo
)

# Importar funciones de ejemplo
from .funciones import division, suma, duplicar
from .operaciones_avanzadas import multiplicar, potencia

# Definir qué se exporta al hacer: from MemBrainPy import *
__all__ = [
    "SistemaP", "Membrana", "Regla",
    "simular_y_visualizar",
    "sistema_basico", "sistema_con_conflictos", "Sistema_complejo",
    "division", "suma", "duplicar",
    "multiplicar", "potencia"
]
